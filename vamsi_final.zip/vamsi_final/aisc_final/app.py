
from flask import Flask, render_template, request
from sklearn.datasets import load_iris

app = Flask(__name__)

# Load the Iris dataset
iris = load_iris()

@app.route('/')
def index():
    species_list = list(set(iris.target_names))
    return render_template('index.html', species_list=species_list)

@app.route('/details', methods=['GET', 'POST'])
def details():
    selected_species = request.form.get('species')
    if selected_species:
        species_index = list(iris.target_names).index(selected_species)
        species_data = iris.data[iris.target == species_index]
        return render_template('details.html', selected_species=selected_species, species_data=species_data)
    return "Please select a species."

if __name__ == '__main__':
    app.run(debug=True)
